# WELCOME TO FLASHBOT GIT

FlashBot is the first NO CODE arbitrage trading bot that leverage flash loans. Enjoy risk free on-chain arbitrage opportunities, automatic pair matching and routing. Just select the network (ETH or BSC) and enter a token address to launch the ARBITRAGE FINDER.

# Disclaimer

Flashbot is an Open Source code as it is, use at your own risk, the development team doesn't take any responsibility for any incorrect use of our software or for any bugs or errors in the code.
